<<<<<<< HEAD
# dg-tienda32bits

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
=======
# Juegos32bitsP1
Tienda de juegos 32 bits Parte 1 Bootcamp Front End 0012
>>>>>>> 30d5e9cea3356f537d8653adb6f544d1399afb7f
