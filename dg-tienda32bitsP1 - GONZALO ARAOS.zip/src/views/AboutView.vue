<template>
  <div class="about">
    <h1>En construcción...</h1>
  </div>
</template>
